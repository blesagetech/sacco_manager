import { cache } from "react";
import { query } from "./db";

export const DEFAULT_BRAND = "#16436f";

export const getBranding = cache(async (organizationId: string) => {
  const { rows } = await query<{
    name: string;
    display_name: string | null;
    primary_color: string | null;
  }>(
    `SELECT o.name, s.display_name, s.primary_color
       FROM organizations o
       LEFT JOIN organization_settings s ON s.organization_id = o.id
      WHERE o.id = $1`,
    [organizationId]
  );

  const row = rows[0];

  return {
    name: row?.display_name || row?.name || "SACCO",
    color: row?.primary_color || DEFAULT_BRAND,
  };
});
