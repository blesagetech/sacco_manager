import type { Metadata } from "next";
import { SetupForm } from "@/components/setup-form";
import { query } from "@/lib/db";

export const metadata: Metadata = { title: "First-time setup" };
export const dynamic = "force-dynamic";

export default async function SetupPage() {
  const { rows } = await query<{ count: string }>("SELECT count(*)::text AS count FROM users");
  return <SetupForm locked={Number(rows[0]?.count ?? 0) > 0} />;
}
