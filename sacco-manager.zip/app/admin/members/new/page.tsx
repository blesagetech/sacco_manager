import type { Metadata } from "next";
import { MemberForm } from "@/components/member-form";
import { PageHeader } from "@/components/ui";
import { requireStaffPage } from "@/lib/guards";
import { permissions } from "@/lib/permissions";

export const metadata: Metadata = { title: "Register member" };

export default async function NewMemberPage() {
  await requireStaffPage(permissions.registerMembers);

  return (
    <>
      <PageHeader
        back={{ href: "/admin/members", label: "Members" }}
        title="Register a member"
        description="This creates the member, their savings account, a share account and a sign-in with a temporary PIN."
      />
      <MemberForm />
    </>
  );
}
