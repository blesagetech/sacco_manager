import { NextResponse } from "next/server";
import { z } from "zod";
import { query, withTransaction } from "@/lib/db";
import { hashPassword } from "@/lib/auth";
import { DEFAULT_BRAND } from "@/lib/org";
import { fail, readJson } from "@/lib/api";

const body = z.object({
  setupKey: z.string().min(1),
  saccoName: z.string().trim().min(2).max(120),
  saccoCode: z.string().trim().min(2).max(30),
  username: z.string().trim().min(3).max(80),
  password: z.string().min(12).max(200),
});

const DEFAULT_CATEGORIES: [string, string][] = [
  ["Constitution", "SACCO constitution and governing documents"],
  ["Loan forms", "Loan applications, agreements and related forms"],
  ["Membership forms", "Membership registration and member service forms"],
  ["Savings and shares", "Savings and share-related forms"],
  ["Policies", "SACCO policies and guidelines"],
  ["Notices", "Official notices and member communications"],
  ["General", "Other official SACCO documents"],
];

export async function POST(req: Request) {
  const parsed = body.safeParse(await readJson(req));
  if (!parsed.success) {
    return fail("Complete every field. The administrator password needs at least 12 characters.");
  }

  const setupKey = process.env.INITIAL_SETUP_KEY;
  if (!setupKey || parsed.data.setupKey !== setupKey) return fail("The setup key is not correct.", 403);

  const existing = await query("SELECT 1 FROM users LIMIT 1");
  if (existing.rowCount) return fail("Setup has already been completed.", 409);

  const hash = await hashPassword(parsed.data.password);

  try {
    await withTransaction(async (client) => {
      const org = await client.query<{ id: string }>(
        "INSERT INTO organizations(name, code) VALUES($1, $2) RETURNING id",
        [parsed.data.saccoName, parsed.data.saccoCode]
      );
      const organizationId = org.rows[0].id;

      await client.query(
        "INSERT INTO users(organization_id, username, password_hash, role) VALUES($1,$2,$3,'SUPER_ADMINISTRATOR')",
        [organizationId, parsed.data.username, hash]
      );

      await client.query(
        "INSERT INTO organization_settings(organization_id, primary_color) VALUES($1,$2) ON CONFLICT DO NOTHING",
        [organizationId, DEFAULT_BRAND]
      );

      for (const [name, description] of DEFAULT_CATEGORIES) {
        await client.query(
          "INSERT INTO document_categories(organization_id, name, description) VALUES($1,$2,$3) ON CONFLICT DO NOTHING",
          [organizationId, name, description]
        );
      }
    });
  } catch (e) {
    const code = (e as { code?: string }).code;
    if (code === "23505") return fail("That SACCO code is already in use.", 409);
    return fail("Setup could not be completed.", 500);
  }

  return NextResponse.json({ ok: true });
}
