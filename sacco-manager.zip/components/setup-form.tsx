"use client";

import { useState } from "react";
import { KeyRound, Landmark, ShieldCheck } from "lucide-react";
import { Alert, Field, SubmitButton } from "@/components/ui";
import { sendJson } from "@/lib/client";

export function SetupForm({ locked }: { locked: boolean }) {
  const [form, setForm] = useState({
    setupKey: "",
    saccoName: "",
    saccoCode: "",
    username: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setBusy(true);
    const { ok, data } = await sendJson("/api/setup", "POST", form);
    setBusy(false);

    if (!ok) {
      setError(data.error || "Setup failed.");
      return;
    }
    setDone(true);
  }

  if (locked || done) {
    return (
      <main className="grid min-h-screen place-items-center px-5">
        <div className="card w-full max-w-md p-8 text-center">
          <ShieldCheck className="mx-auto text-[var(--brand)]" size={36} />
          <h1 className="mt-4 text-xl font-bold">
            {done ? "Your SACCO is ready" : "Setup is complete"}
          </h1>
          <p className="mt-2 text-sm text-[var(--muted)]">
            {done
              ? "The administrator account has been created."
              : "An administrator account already exists. Use the normal sign-in page."}
          </p>
          <a href="/login" className="btn btn-primary mt-6">
            Go to sign in
          </a>
        </div>
      </main>
    );
  }

  return (
    <main className="grid min-h-screen place-items-center px-5 py-10">
      <form onSubmit={submit} className="card w-full max-w-xl p-6 sm:p-8">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[var(--brand-soft)] text-[var(--brand)]">
            <Landmark size={22} />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight">First-time setup</h1>
            <p className="text-sm text-[var(--muted)]">Create your SACCO and its first administrator.</p>
          </div>
        </div>

        <div className="mt-7 grid gap-4 sm:grid-cols-2">
          <Field label="Setup key" className="sm:col-span-2" hint="The INITIAL_SETUP_KEY value from your environment settings.">
            <input
              required
              type="password"
              className="field"
              value={form.setupKey}
              onChange={(e) => setForm({ ...form, setupKey: e.target.value })}
            />
          </Field>
          <Field label="SACCO name" className="sm:col-span-2">
            <input
              required
              className="field"
              value={form.saccoName}
              onChange={(e) => setForm({ ...form, saccoName: e.target.value })}
            />
          </Field>
          <Field label="SACCO code" hint="A short code, for example KSACCO.">
            <input
              required
              className="field"
              value={form.saccoCode}
              onChange={(e) => setForm({ ...form, saccoCode: e.target.value.toUpperCase() })}
            />
          </Field>
          <Field label="Administrator username">
            <input
              required
              autoCapitalize="none"
              className="field"
              value={form.username}
              onChange={(e) => setForm({ ...form, username: e.target.value })}
            />
          </Field>
          <Field label="Administrator password" className="sm:col-span-2" hint="At least 12 characters.">
            <input
              required
              type="password"
              minLength={12}
              autoComplete="new-password"
              className="field"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
            />
          </Field>
        </div>

        {error && (
          <div className="mt-5">
            <Alert tone="error">{error}</Alert>
          </div>
        )}

        <SubmitButton busy={busy} icon={KeyRound} className="mt-6 w-full">
          Create SACCO
        </SubmitButton>
      </form>
    </main>
  );
}
